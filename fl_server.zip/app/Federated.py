import copy

import numpy as np

import logging
logger = logging.getLogger(__name__)

class FederatedServer:
    max_count = 3
    global_weight = None
    local_weights = []
    current_count = 0
    current_round = 0

    def __init__(self):
        print("Federated init")

    @classmethod
    def update(cls, local_weight):
        weight_list = []
        for i in range(len(local_weight)): 
            temp = np.array(local_weight[i])
            weight_list.append(temp)

        cls.current_count += 1 # increment current count
        cls.local_weights.append(weight_list) # append the received local weight to the local weights list that contains all other

        if cls.current_count == cls.max_count: # if current count reaches the max count
            cls.avg() # fed avg 
            cls.current_count = 0
            cls.current_round += 1
            logger.info("----------------------------------------")
            logger.info("current round : {}".format(cls.current_round))
            logger.info("----------------------------------------")

    @classmethod
    def avg(cls):
        temp_weight = cls.local_weights.pop() #   weight의 shape를 모르므로, 하나를 꺼내어 사용

        for i in range(len(temp_weight)):
            temp_weight[i] = np.array(temp_weight[i])

        temp_weight = np.array(temp_weight) 

        for i in range(len(cls.local_weights)):
            for j in range(len(cls.local_weights[i])):
                temp = np.array(cls.local_weights[i][j])
                temp_weight[j] = temp_weight[j] + temp



        cls.global_weight = np.divide(temp_weight, cls.max_count) # FedAvg
        
        cls.local_weights = []  # reset local weights
      

    @classmethod
    def get_avg(cls):
        return cls.global_weight

    @classmethod
    def get_current_count(cls):
        return cls.current_count

    @classmethod
    def get_current_round(cls):
        return cls.current_round
